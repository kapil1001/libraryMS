<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Profile extends Model
{
    protected $fillable = ['phone', 'address', 'dob', 'id_type', 'id_number', 'id_image', 'image', 'user_id'];

    public function user(){
        return $this->belongsTo('App\User');
    }
}
