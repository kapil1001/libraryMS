<?php

namespace App\Http\Controllers;

use App\Fine;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function admin_index()
    {
        $total_fee_collected = Fine::where('payment_status', '=', 0)->sum('amount_accrued');
        $total_fee_due = Fine::where('payment_status', '=', 1)->sum('amount_accrued');
        $total_books_overdue = Fine::where('payment_status', '=', 0)->count();
        return view('admin.home')->with('total_fee_collected', $total_fee_collected)->with('total_fee_due', $total_fee_due)->with('total_books_overdue', $total_books_overdue);

    }

    public function borrower_index()
    {
        $user = Auth::user();
        Fine::updateFine($user->id);
        $borrowings = $user->book_user;
        return view('borrower.home')->with('borrowings', $borrowings)->with('user', $user);

    }

    public function profile(){
        $user = Auth::user();
        return view('borrower.profile')->with('user', $user);
    }

    public function change_password(Request $request){
        $this->validate($request, [
            'password' => 'required|confirmed'
        ]);


        $user = Auth::user();
        $user->password = Hash::make($request->password);
        $user->save();
        Session::flash('success', 'Password changed successfully');
        return redirect()->route('borrower.profile');
    }
}
