<?php

namespace App\Http\Controllers;

use App\Profile;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::where('user_type', '=', 'admin')->get();
        return view('admin.user.index')->with('users', $users);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.user.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'email' => 'required|email|unique:users',
            'name' => 'required'
        ]);

        $user = User::create([
            'email' => $request->email,
            'name' => $request->name,
            'user_type' => 'admin',
            'password' => Hash::make($request->email)
        ]);
        Session::flash('success', 'User account has been created successfully');


        return redirect()->route('user.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::find($id);

        if($user->delete()){
            Session::flash('success', 'User account deleted successfully');
        }

        return redirect()->route('user.index');
    }

    public function profile(){
        return view('admin.user.profile');
    }

    public function profile_update(Request $request){
        $this->validate($request,[
            'email' => 'required|email',
            'name' => 'required',
            'password' => 'confirmed'
        ]);

        $user = Auth::user();
        $user->name = $request->name;
        $user->email = $request->email;
        if(!empty($request->password) && !empty($request->password_confirmation)){

            $user->password = Hash::make($request->password);
        }

        if($user->save()){
            Session::flash('success', 'Your profile updated successfully');
        }

        return redirect()->route('user.profile');
    }
}
