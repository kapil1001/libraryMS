<?php

namespace App\Http\Controllers;

use App\BookUser;
use App\Fine;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class ReturnController extends Controller
{
    public function index(){
        $borrowers = User::where('user_type', '=', 'borrower')->get();
        return view('admin.return.index')->with('borrowers', $borrowers);
    }

    public function search(Request $request){
        $borrowers = User::where('name', 'like', '%'.$request->name.'%')->get();
        return view('admin.return.index')->with('borrowers', $borrowers);
    }

    public function borrower_book($borrower_id){
        Fine::updateFine($borrower_id);

        $borrower_fine = array();
        $borrower = User::find($borrower_id);
        $books_borrowed = $borrower->book_user()->where('status', '=', 0)->get();

        foreach ($books_borrowed as $bb){
            if(!empty($bb->fine)){
                array_push($borrower_fine, $bb->fine);
            }
        }
        return view('admin.return.borrower-book')->with('borrower', $borrower)->with('books_borrowed', $books_borrowed)->with('borrower_fine', $borrower_fine);
    }

    public function return_borrower_book_single($id){
        $book_user = BookUser::find($id);
        $fine = $book_user->fine;

        $make_return = true;
        if(!empty($fine)){
            if($fine->payment_status == 0){
                $make_return = false;
            }
        }
        if($make_return){
            $book = $book_user->book;
            $stock = $book->stock;
            $stock->borrowed = $stock->borrowed - 1;
            $stock->save();

            $book_user->status = 1;
            $book_user->save();
            Session::flash('success',  $book_user->book->title.' book returned successfully');
        }else{
            Session::flash('info', 'Please make the payment first to return the book.');
        }

        return redirect()->back();
    }

    public function return_borrower_book_all($borrower_id){
        $borrower = User::find($borrower_id);
        $books_borrowed = $borrower->book_user()->where('status', '=', 0)->get();

       if(count($books_borrowed)){
           foreach ($books_borrowed as $bb){
               $fine = $bb->fine;
               $make_return = true;
               if(!empty($fine)){
                   if($fine->payment_status == 0){
                       $make_return = false;
                   }
               }
               if($make_return){
                   $book = $bb->book;
                   $stock = $book->stock;
                   $stock->borrowed = $stock->borrowed - 1;
                   $stock->save();
                   $bb->status = 1;
                   $bb->save();
               }
           }
           Session::flash('success',  'All books returned successfully');
       }else{
           Session::flash('info', 'No books borrowed to return');
       }
        return redirect()->back();
    }

    public function pay($id){
        $fee = Fine::find($id);
        $fee->payment_status = 1;
        $fee->save();
        Session::flash('success', 'Payment status changed to paid.');
        return redirect()->back();
    }
}
