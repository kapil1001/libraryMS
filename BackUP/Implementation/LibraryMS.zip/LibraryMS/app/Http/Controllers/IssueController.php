<?php

namespace App\Http\Controllers;

use App\Book;
use App\BookUser;
use App\Cart;
use App\Genre;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class IssueController extends Controller
{
    public function index(){
        $borrowers = User::where('user_type', '=', 'borrower')->get();
        return view('admin.issue.index')->with('borrowers', $borrowers);
    }

    public function search(Request $request){
        $borrowers = User::where('name', 'like', '%'.$request->name.'%')->get();
        return view('admin.issue.index')->with('borrowers', $borrowers);
    }

    public function borrower_book($borrower_id){
        $borrower = User::find($borrower_id);
        $books = Book::all();
        $genres = Genre::all();
        $borrower_cart = Cart::where('user_id', '=', $borrower_id)->get();
        $borrowed_list = BookUser::where('user_id', '=', $borrower_id)->where('status', '=', 0)->get();
        return view('admin.issue.borrower-book')->with('books', $books)->with('genres', $genres)->with('borrower', $borrower)->with('borrower_id', $borrower_id)->with('borrower_cart', $borrower_cart)->with('borrowed_list', $borrowed_list);
    }

    public function search_book_title_author(Request $request, $borrower_id){
        $books = Book::where('title', 'like', '%'.$request->title_author.'%')->orWhere('author', 'like', '%'.$request->title_author.'%')->get();
        $borrower = User::find($borrower_id);
        $genres = Genre::all();
        $borrower_cart = Cart::where('user_id', '=', $borrower_id)->get();
        $borrowed_list = BookUser::where('user_id', '=', $borrower_id)->where('status', '=', 0)->get();
        return view('admin.issue.borrower-book')->with('books', $books)->with('genres', $genres)->with('borrower', $borrower)->with('borrower_id', $borrower_id)->with('borrower_cart', $borrower_cart)->with('borrowed_list', $borrowed_list);
    }

    public function filter_book_genre(Request $request, $borrower_id){
        $books = Book::where('genre_id', '=', $request->genre)->get();
        $borrower = User::find($borrower_id);
        $genres = Genre::all();
        $borrower_cart = Cart::where('user_id', '=', $borrower_id)->get();
        $borrowed_list = BookUser::where('user_id', '=', $borrower_id)->where('status', '=', 0)->get();
        return view('admin.issue.borrower-book')->with('books', $books)->with('genres', $genres)->with('borrower', $borrower)->with('borrower_id', $borrower_id)->with('borrower_cart', $borrower_cart)->with('borrowed_list', $borrowed_list);
    }

    public function borrower_cart_book_add($book_id, $borrower_id){
        $check_cart = Cart::where('user_id', '=', $borrower_id)->where('book_id', '=', $book_id)->count();
        $check_already_taken = BookUser::where('status', '=', 0)->where('user_id', '=', $borrower_id)->where('book_id', '=', $book_id)->count();
        if($check_already_taken == 0) {
            if ($check_cart == 0) {
                Cart::create([
                    'user_id' => $borrower_id,
                    'book_id' => $book_id,
                ]);

                Session::flash('success', 'Successfully added to issue list');
            } else {
                Session::flash('info', 'Book is already added to issue list');
            }
        }else{
            Session::flash('info', 'This book is already issued to this borrower');
        }

       return redirect()->back();
    }

    public function borrower_cart_book_remove($id){
        $cart = Cart::find($id);
        $cart->delete();

        Session::flash('success', 'Successfully removed book form issue list');
        return redirect()->back();
    }

    public function borrower_cart_clear($borrower_id){
        $cart_books = Cart::where('user_id', '=', $borrower_id)->get();
        foreach($cart_books as $c){
            $c->delete();
        }
        Session::flash('success', 'Issue list has been cleared');
        return redirect()->back();
    }

    public function borrower_cart_check_out(Request $request, $borrower_id){
        $borrower = User::find($borrower_id);
        $cart = $borrower->carts;
        if(count($cart) > 0){
            $this->validate($request, [
                'borrow_period' => 'Required|numeric|min:1'
            ]);
            foreach ($cart as $c){
                BookUser::create([
                    'user_id' => $c->user_id,
                    'book_id' => $c->book_id,
                    'borrowed_date' => date('Y-m-d'),
                    'borrow_period' => $request->borrow_period
                ]);

                $stock = $c->book->stock;
                $stock->borrowed = $stock->borrowed+1;
                $stock->save();

                $c->delete();
                Session::flash('success', 'Books in the list has been issued');
            }
        }else{
                Session::flash('info', 'Issue List is empty. Add one or more books to issue');
        }
        return redirect()->back();
    }
}
