<?php

namespace App\Http\Controllers;


use App\Fine;
use App\Profile;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class BorrowerController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $borrowers = User::where('user_type', '=', 'borrower')->get();
        return view('admin.borrower.index')->with('borrowers', $borrowers);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.borrower.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required',
            'phone' => 'required|numeric',
            'address' => 'required',
            'dob' => 'required',
            'id_type' => 'required',
            'id_number' => 'required',
            'id_image' => 'required|image',
            'image' => 'required|image'
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->email)
        ]);
        $id_image = $request->id_image;
        $id_new_name = time()."_".$id_image->getClientOriginalName();
        $profile_image = $request->image;
        $profile_new_name = time()."_".$profile_image->getClientOriginalName();
        Profile::create([
            'address' => $request->address,
            'phone' => $request->phone,
            'dob' => $request->dob,
            'id_type' => $request->id_type,
            'id_number' => $request->id_number,
            'id_image' => $id_new_name,
            'image' => $profile_new_name,
            'user_id' => $user->id
        ]);

        Storage::putFileAs('public/images/identity', $id_image, $id_new_name);
        Storage::putFileAs('public/images/borrower', $profile_image, $profile_new_name);
        Session::flash('success', 'Borrower added successfully.');


        return redirect()->route('borrower.view');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $borrower = User::find($id);
        return view('admin.borrower.edit')->with('borrower', $borrower);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required',
            'phone' => 'required|numeric',
            'address' => 'required',
            'dob' => 'required',
            'id_type' => 'required',
            'id_number' => 'required'
        ]);

        if($request->has('id_image')){
            $this->validate($request, [
                'id_image' => 'image'
            ]);
        }

        if($request->has('image')){
            $this->validate($request, [
                'image' => 'image'
            ]);
        }

        $member = User::find($id);
        $member->name = $request->name;
        $member->email = $request->email;
        $member->save();

        $profile = $member->profile;
        $profile->phone = $request->phone;
        $profile->address = $request->address;
        $profile->dob = $request->dob;
        $profile->id_type = $request->id_type;
        $profile->id_number = $request->id_number;
        if($request->has('id_image')){
            $id_image = $request->id_image;
            $id_new_name = time()."_".$id_image->getClientOriginalName();
            Storage::putFileAs('public/images/identity', $id_image, $id_new_name);
            Storage::delete('public/images/identity/'.$profile->id_image);
            $profile->id_image = $id_new_name;
        }


        if($request->has('image')){
            $profile_image = $request->image;
            $profile_new_name = time()."_".$profile_image->getClientOriginalName();
            Storage::putFileAs('public/images/borrower', $profile_image, $profile_new_name);
            Storage::delete('public/images/borrower/'.$profile->image);
            $profile->image = $profile_new_name;
        }

        $profile->save();
        Session::flash('success', 'Member updated successfully');

        return redirect()->route('borrower.view');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $member = User::find($id);

        $old_id_image = $member->profile->id_image;
        $old_profile_image = $member->profile->image;
        Storage::delete('public/images/identity/'.$old_id_image);
        Storage::delete('public/images/borrower/'.$old_profile_image);
        $member->delete();
        Session::flash('success', 'borrower deleted successfully');

        return redirect()->route('borrower.view');
    }

    public function details($id){
        $borrower = User::find($id);

        return view('admin.borrower.details')->with('borrower', $borrower);
    }

    public function books_borrowed($id){
        Fine::updateFine($id);
        $borrower = User::find($id);
        $borrowings = $borrower->book_user;

        return view('admin.borrower.books-borrowed')->with('borrowings', $borrowings)->with('borrower', $borrower);
    }

    public function search(Request $request){
        $borrowers = User::where('user_type', '=', 'borrower')->where('name', 'like', '%'.$request->name.'%')->get();
        return view('admin.borrower.index')->with('borrowers', $borrowers);
    }

}
