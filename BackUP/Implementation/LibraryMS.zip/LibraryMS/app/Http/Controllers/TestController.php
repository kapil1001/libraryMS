<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;

class TestController extends Controller
{
    public function updateFine($borrower_id){
        $borrower = User::find($borrower_id);
        $borrowings = $borrower->book_user;
        foreach ($borrowings as $b){
            $date1 = date_create($b->borrowed_date);
            $date2 = date_create(date('Y-m-d'));
            $interval = date_diff($date1, $date2)->d;
        }
    }
}
