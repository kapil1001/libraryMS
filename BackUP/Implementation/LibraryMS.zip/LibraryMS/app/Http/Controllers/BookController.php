<?php

namespace App\Http\Controllers;

use App\Book;
use App\BookImage;
use App\Stock;
use App\Genre;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
class BookController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $books = Book::all();
        return view('admin.book.index')->with('books', $books);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $genres = Genre::all();
        return view('admin.book.create')->with('genres', $genres);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'isbn' => 'required|unique:books',
            'title' => 'required',
            'author' => 'required',
            'edition' => 'required',
            'edition_year' => 'required',
            'publisher' => 'required',
            'total_pages' => 'required|numeric',
            'price' => 'required|numeric',
            'notes' => 'required',
            'quantity' => 'required|numeric|min:1',
            'genre' => 'required|numeric',
            'images' => 'required',
            'images.*' => 'image'
        ]);

        $book = Book::create([
            'isbn' => $request->isbn,
            'title' => $request->title,
            'author' => $request->author,
            'edition' => $request->edition,
            'edition_year' => $request->edition_year,
            'publisher' => $request->publisher,
            'total_pages' => $request->total_pages,
            'price' => $request->price,
            'notes' => $request->notes,
            'genre_id' => $request->genre,
        ]);

        Stock::create(['book_id' => $book->id,'stock' => $request->quantity, 'borrowed' => '0']);

        $book_images = $request->images;
        foreach($book_images as $image){
            $new_image_name = time()."_".$image->getClientOriginalName();
            if(Storage::putFileAs('public/images/book', $image, $new_image_name)){
                BookImage::create([
                    'book_id' => $book->id,
                    'image' => $new_image_name
                ]);
            }
        }

        Session::flash('success', 'Book created successfully.');


        return redirect()->route('book.view');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $book = Book::find($id);
        $genres = Genre::all();
        return view('admin.book.edit')->with('book', $book)->with('genres', $genres);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'isbn' => 'required',
            'title' => 'required',
            'author' => 'required',
            'edition' => 'required',
            'edition_year' => 'required',
            'publisher' => 'required',
            'total_pages' => 'required|numeric',
            'price' => 'required|numeric',
            'quantity' => 'required|numeric|min:1',
            'notes' => 'required',
            'genre' => 'required|numeric'
        ]);

        $book = Book::find($id);
        if($book->stock->borrowed > $request->quantity) {
            $validator->after(function ($validator) {
                $validator->errors()->add('quantity', 'You cannot make available stock less then book issued/borrowed.');
            });
        }
        $validator->validate();


        if($request->has('images')){
            $this->validate($request, [
                'images' => 'required',
                'images.*' => 'image'
            ]);
        }


        $book->isbn = $request->isbn;
        $book->title = $request->title;
        $book->author = $request->author;
        $book->edition = $request->edition;
        $book->edition_year = $request->edition_year;
        $book->publisher = $request->publisher;
        $book->total_pages = $request->total_pages;
        $book->price = $request->price;
        $book->notes = $request->notes;
        $book->genre_id = $request->genre;
        $book->save();

        $stock = $book->stock;
        $stock->stock = $request->quantity;
        $stock->save();

        if($request->hasFile('images')){
            $old_images = $book->images;
            if(count($old_images) > 0){
                foreach($old_images as $image){
                    if(Storage::delete('public/images/book/'.$image->image)){
                        $image->delete();
                    }
                }
            }

            $book_images = $request->images;
            foreach($book_images as $image){
                $new_image_name = time()."_".$image->getClientOriginalName();
                if(Storage::putFileAs('public/images/book', $image, $new_image_name)){
                    BookImage::create([
                        'book_id' => $book->id,
                        'image' => $new_image_name
                    ]);
                }
            }
        }

        Session::flash('success', 'Book updated successfully');

        return redirect()->route('book.view');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $book = Book::find($id);

        $old_images = $book->images;
        if(count($old_images) > 0){
            foreach($old_images as $image){
                if(Storage::delete('public/images/book/'.$image->image)){
                    $image->delete();
                }
            }
        }
        $book->delete();
        Session::flash('success', 'Book deleted successfully');

        return redirect()->route('book.view');
    }

    public function details($id){
        $book = Book::find($id);

        return view('admin.book.details')->with('book', $book);
    }

    public function issued_borrower($id){
        $book = Book::find($id);
        $borrowings = $book->book_user;
        return view('admin.book.issued-borrowers')->with('borrowings', $borrowings)->with('book', $book);
    }

    public function search(Request $request){
        $books = Book::where('title', 'like', '%'.$request->title.'%')->get();
        return view('admin.book.index')->with('books', $books);
    }
}
