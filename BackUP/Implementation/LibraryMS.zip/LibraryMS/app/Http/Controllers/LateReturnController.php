<?php

namespace App\Http\Controllers;

use App\BookUser;
use App\Fine;
use App\User;
use Illuminate\Support\Facades\Notification;
use Illuminate\Http\Request;

class LateReturnController extends Controller
{

    public function index(){
        Fine::updateAllFines();
        $borrowers = array();
        $fines = Fine::all();
        foreach ($fines as $fine){
            $borrowing = $fine->book_user;
            if(!in_array($borrowing->user, $borrowers)){
                array_push($borrowers, $borrowing->user);
            }
        return view('admin.late.index')->with('late_borrowers', $borrowers);
        }
    }

    public function send_mail($borrower_id){
        $to = array();
        $borrower = User::find($borrower_id);
        array_push($to, $borrower);

        $borrowings = $borrower->book_user;

        $message = "You have not returned book('s) titled ";
        foreach ($borrowings as $b){
            $fine = $b->fine;
            $book = $b->book;
            if(!empty($fine)){
                $message .= $book->title . " (Days Delayed: " .$fine->late_days_count. " & Fine Accrued: ".$fine->amount_accrued." ) , ";
            }
        }
        Notification::send($to, new \App\Notifications\DelayNotification($borrower, substr($message,0,-3)));
        return redirect()->back();
    }

}
