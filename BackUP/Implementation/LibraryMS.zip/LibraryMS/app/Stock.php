<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Stock extends Model
{
    protected $fillable = ['stock', 'borrowed', 'book_id'];

    public function book(){
        return $this->belongsTo('App\Book');
    }
}
