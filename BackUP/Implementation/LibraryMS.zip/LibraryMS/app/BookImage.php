<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookImage extends Model
{
    protected $fillable = ['image', 'book_id'];

    public function genre(){
        return $this->belongsTo('App\Book');
    }
}
