<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fine extends Model
{
    protected $fillable = ['late_days_count', 'amount_accrued', 'payment_status', 'book_user_id'];

    public function book_user(){
        return $this->belongsTo('App\BookUser');
    }

    public static function updateFine($borrower_id){
        $borrower = User::find($borrower_id);
        $borrowings = $borrower->book_user;
        foreach ($borrowings as $b){
            $date1 = date_create($b->borrowed_date);
            $date2 = date_create(date('Y-m-d'));
            $interval = date_diff($date1, $date2)->days;
            if($interval > $b->borrow_period){
                $fine = $b->fine;
                if(!empty($fine)){
                    $fine->late_days_count = $interval;
                    $fine->amount_accrued = 100 * $interval;
                    $fine->save();
                }else{
                    Fine::create([
                        'late_days_count' => $interval,
                        'amount_accrued' => 100 * $interval,
                        'book_user_id' => $b->id
                    ]);
                }
            }
        }
    }

    public static function updateAllFines(){
        $borrowers = User::where('user_type', '=', 'borrower')->get();
        foreach ($borrowers as $borrower){
            self::updateFine($borrower->id);
        }
    }
}
