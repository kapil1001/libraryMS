<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookUser extends Model
{
    protected $fillable = ['book_id', 'user_id', 'borrowed_date', 'borrow_period', 'status'];
    public function book(){
        return $this->belongsTo('App\Book');
    }
    public function user(){
        return $this->belongsTo('App\User');
    }

    public function fine(){
        return $this->hasOne('App\Fine');
    }
}
