<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    protected $fillable = ['isbn', 'title', 'author', 'edition', 'edition_year', 'publisher', 'total_pages', 'price', 'notes', 'genre_id'];

    public function genre(){
        return $this->belongsTo('App\Genre');
    }

    public function images(){
        return $this->hasMany('App\BookImage');
    }

    public function stock(){
        return $this->hasOne('App\Stock');
    }

    public function carts(){
        return $this->hasMany('App\Cart');
    }

    public function book_user(){
        return $this->hasMany('App\BookUser');
    }
}
