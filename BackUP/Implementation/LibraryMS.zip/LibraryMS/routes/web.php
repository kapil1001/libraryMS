<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Auth;

Route::get('/', function () {
    if(Auth::check()){
        if(Auth::user()->user_type == "admin"){
            return redirect()->route('admin.home');
        }else{
            return redirect()->route('borrower.home');
        }
    }else{
        return view('welcome');
    }
});

Auth::routes(['register' => false]);

Route::group(['middleware' => ['auth']], function(){


    Route::get('/borrower/home', 'HomeController@borrower_index')->name('borrower.home');
    Route::get('/borrower/profile', 'HomeController@profile')->name('borrower.profile');
    Route::post('/borrower/password/change', 'HomeController@change_password')->name('borrower.password.change');


Route::group(['middleware' => ['user']], function(){


    Route::get('/admin/home', 'HomeController@admin_index')->name('admin.home');
    //genre
    Route::get('/genre/view', 'GenreController@index')->name('genre.view');
    Route::get('/genre/create', 'GenreController@create')->name('genre.create');
    Route::post('/genre/store', 'GenreController@store')->name('genre.store');
    Route::get('/genre/edit/{id}', 'GenreController@edit')->name('genre.edit');
    Route::post('/genre/update/{id}', 'GenreController@update')->name('genre.update');
    Route::get('/genre/delete/{id}', 'GenreController@destroy')->name('genre.delete');

    //book
    Route::get('/book/view', 'BookController@index')->name('book.view');
    Route::get('/book/create', 'BookController@create')->name('book.create');
    Route::post('/book/store', 'BookController@store')->name('book.store');
    Route::get('/book/edit/{id}', 'BookController@edit')->name('book.edit');
    Route::post('/book/update/{id}', 'BookController@update')->name('book.update');
    Route::get('/book/delete/{id}', 'BookController@destroy')->name('book.delete');
    Route::get('/book/details/{id}', 'BookController@details')->name('book.details');
    Route::get('/book/issued/borrower/{id}', 'BookController@issued_borrower')->name('book.issued.borrower');
    Route::get('/book/search', 'BookController@search')->name('book.search');


    //borrower
    Route::get('/borrower/view', 'BorrowerController@index')->name('borrower.view');
    Route::get('/borrower/create', 'BorrowerController@create')->name('borrower.create');
    Route::post('/borrower/store', 'BorrowerController@store')->name('borrower.store');
    Route::get('/borrower/edit/{id}', 'BorrowerController@edit')->name('borrower.edit');
    Route::post('/borrower/update/{id}', 'BorrowerController@update')->name('borrower.update');
    Route::get('/borrower/delete/{id}', 'BorrowerController@destroy')->name('borrower.delete');
    Route::get('/borrower/details/{id}', 'BorrowerController@details')->name('borrower.details');
    Route::get('/borrower/books/borrowed/{id}', 'BorrowerController@books_borrowed')->name('borrower.books.borrowed');
    Route::get('/borrower/search', 'BorrowerController@search')->name('borrower.search');


    //issue
    Route::get('/issue/index', 'IssueController@index')->name('issue.index');
    Route::get('/issue/search', 'IssueController@search')->name('issue.search');
    Route::get('/issue/borrower/book/{borrower_id}', 'IssueController@borrower_book')->name('issue.borrower.book');
    Route::get('/issue/book/search/title-author/{borrower_id}', 'IssueController@search_book_title_author')->name('issue.book.search-title-author');
    Route::get('/issue/book/filter/genre/{borrower_id}', 'IssueController@filter_book_genre')->name('issue.book.filter-genre');
    Route::get('/issue/cart/add/{book_id}/{borrower_id}', 'IssueController@borrower_cart_book_add')->name('issue.cart.add');
    Route::get('/issue/cart/remove/{id}', 'IssueController@borrower_cart_book_remove')->name('issue.cart.remove');
    Route::get('/issue/cart/clear/{borrower_id}', 'IssueController@borrower_cart_clear')->name('issue.cart.clear');
    Route::get('/issue/cart/check-out/{borrower_id}', 'IssueController@borrower_cart_check_out')->name('issue.cart.check-out');

    //return
    Route::get('/return/index', 'ReturnController@index')->name('return.index');
    Route::get('/return/search', 'ReturnController@search')->name('return.search');
    Route::get('/return/borrower/book/{borrower_id}', 'ReturnController@borrower_book')->name('return.borrower.book');
    Route::get('/return/borrower/book/single/{id}', 'ReturnController@return_borrower_book_single')->name('return.borrower.single');
    Route::get('/return/borrower/single/{borrower_id}', 'ReturnController@return_borrower_book_all')->name('return.borrower.all');
    Route::get('/return/borrower/fee/pay/{id}', 'ReturnController@pay')->name('borrower.fine.pay');

    //late
    Route::get('/late/index', 'LateReturnController@index')->name('late.index');
    Route::get('/late/send-mail/{borrower_id}', 'LateReturnController@send_mail')->name('late.send.mail');

    //user
    Route::get('user/index', 'UserController@index')->name('user.index');
    Route::get('user/delete/{id}', 'UserController@destroy')->name('user.delete');
    Route::get('user/create', 'UserController@create')->name('user.create');
    Route::post('user/store', 'UserController@store')->name('user.store');
    Route::get('user/profile', 'UserController@profile')->name('user.profile');
    Route::post('user/profile/update', 'UserController@profile_update')->name('user.profile.update');
   });
});

