$(document).ready(function() {

    $(".notification").slideDown(300);

    $(".notification").delay(4000).fadeOut("slow");


});
