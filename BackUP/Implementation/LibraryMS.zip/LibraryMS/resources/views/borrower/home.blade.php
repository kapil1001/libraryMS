@extends('layouts.app-borrower')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Borrower Dashboard</div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 mx-auto p-0 card border border-info">
                            <div class="card-header bg-success">
                                <h5 class="text-center text-light">Books Borrowed by {{$user->name}}</h5>
                            </div>
                            <div class="card-body table-responsive">
                                <table class="table table-bordered table-stripped">
                                    <thead  class="thead-dark">
                                    <tr>
                                        <th>S.N</th>
                                        <th>Genre</th>
                                        <th>ISBN</th>
                                        <th>Title</th>
                                        <th>Author</th>
                                        <th>Edition</th>
                                        <th>publisher</th>
                                        <th>Borrow Date</th>
                                        <th>Due Date</th>
                                        <th>Arrears Days</th>
                                        <th>Accrued Fine</th>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    @php $i = 1;  @endphp

                                    @if(count($borrowings) > 0)
                                        @foreach($borrowings as $borrowing)
                                            @php
                                                $book = $borrowing->book;
                                                $fine = $borrowing->fine;
                                                $date=date_create($borrowing->borrowed_date);
                                                date_add($date,date_interval_create_from_date_string($borrowing->borrow_period." days"));
                                                $return_date = date_format($date,"Y-m-d");
                                            @endphp
                                            <tr>
                                                <td>{{$i}}</td>
                                                <td>{{$book->genre->name}}</td>
                                                <td>{{$book->isbn}}</td>
                                                <td>{{$book->title}}</td>
                                                <td>{{$book->author}}</td>
                                                <td>{{$book->edition. " (".$book->edition_year.")"}}</td>
                                                <td>{{$book->publisher}}</td>
                                                <td>{{$borrowing->borrowed_date}}</td>
                                                <td>{{$return_date}}</td>
                                                <td>
                                                    @if(!empty($fine))
                                                        {{$fine->late_days_count}}
                                                    @else
                                                        {{NA}}
                                                    @endif
                                                </td>
                                                <td>
                                                    @if(!empty($fine))
                                                        {{$fine->amount_accrued}}
                                                    @else
                                                        {{NA}}
                                                    @endif
                                                </td>

                                            </tr>
                                            @php $i++;  @endphp
                                        @endforeach
                                    @else
                                        <tr><td class="text-center text-danger" colspan="7">No Book Borrowed Yet</td></tr>
                                    @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
