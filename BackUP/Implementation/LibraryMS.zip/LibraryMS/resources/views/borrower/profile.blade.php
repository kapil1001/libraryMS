@extends('layouts.app-borrower')

@section('content')
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Borrower Profile</div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-10 mx-auto p-0 card border border-info">
                                <div class="card-header bg-success">
                                    <h3 class="text-center text-light">{{$user->name}}</h3>
                                </div>
                                <div class="card-body table-responsive">
                                    <div class="col d-flex justify-content-center">

                                        <a href="{{asset('storage/images/identity/'.$user->profile->id_image)}}" target="_blank"><img src="{{asset('storage/images/identity/'.$user->profile->id_image)}}" alt="" style="height:150px; width:150px;" class="img-thumbnail p-2 m-3"></a>
                                        <a href="{{asset('storage/images/borrower/'.$user->profile->image)}}" target="_blank"><img src="{{asset('storage/images/borrower/'.$user->profile->image)}}" alt="" style="height:150px; width:150px;" class="img-thumbnail p-2 m-3"></a>

                                    </div>
                                    <table class="table table-borderless table-striped border border-success">
                                        <tbody>
                                        <tr>
                                            <th>Name</th>
                                            <td>{{$user->name}}</td>
                                            <th>Email</th>
                                            <td>{{$user->email}}</td>
                                        </tr>

                                        <tr>
                                            <th>Phone</th>
                                            <td>{{$user->profile->phone}}</td>
                                            <th>Address</th>
                                            <td>{{$user->profile->address}}</td>
                                        </tr>

                                        <tr>
                                            <th>DOB</th>
                                            <td>{{$user->profile->dob}}</td>
                                            <th>Identity Type</th>
                                            <td>{{$user->profile->id_type}}</td>
                                        </tr>

                                        <tr>
                                            <th>Identity Number</th>
                                            <td colspan="3">{{$user->profile->id_number}}</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="card-footer bg-secondary d-flex justify-content-center">
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#changePWModalCenter">
                                       Change Password
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="changePWModalCenter" tabindex="-1" role="dialog" aria-labelledby="changePWModalCenter" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                       <div class="col-md-8 mx-auto">
                           <form action="{{route('borrower.password.change')}}" method="post">
                               {{csrf_field()}}
                               <div class="form-group">
                                   <label for="password">Password</label>
                                   <input type="password" name="password" class="form-control">
                               </div>
                               <div class="form-group">
                                   <label for="password_confirmation">Confirm Password</label>
                                   <input type="password" name="password_confirmation" class="form-control">
                               </div>

                               <div class="form-group">
                                   <input type="submit" value="Change Password" class="btn btn-success">
                               </div>
                           </form>
                       </div>
                    </div>

                </div>
            </div>
        </div>

@endsection
