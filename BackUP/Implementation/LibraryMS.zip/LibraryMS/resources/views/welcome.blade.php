@extends('layouts.app-borrower')

@section('content')
    <div class="row justify-content-center welcome-bg">
        <div class="col- dark-overlay">
            <div class="col-md-12">
                <h1 class="text-center text-light margin-label">Welcome To Library Management System</h1>
            </div>
        </div>
    </div>
@endsection
