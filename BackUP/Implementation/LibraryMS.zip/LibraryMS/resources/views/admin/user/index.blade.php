@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">User Section</div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                            <a href="{{ route('user.create') }}" class="btn btn-info text-light float-right">Create User</a>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-8 mx-auto table-responsive table-sm">
                                <table class="table table-bordered table-stripped">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>S.N</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    @if(count($users) > 0)
                                        @php $i = 1 @endphp

                                        @foreach($users as $user)

                                            <tr>
                                                <td>{{ $i }}</td>
                                                <td>{{$user->name}}</td>
                                                <td>{{$user->email}}</td>
                                                <td>
                                                    @if(Auth::user()->id != $user->id)
                                                    <a href="{{route('user.delete', ['id' => $user->id])}}" class="btn btn-danger btn-sm">Delete</a>
                                                    @endif
                                                </td>
                                            </tr>
                                            @php $i++; @endphp
                                        @endforeach
                                    @else
                                        <tr><td colspan="4" class="text-danger text-center">No users yet</td></tr>

                                    @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
