@extends('layouts.app')

@section('content')

        <div class="row">
            <div class="col-md-12">
                <div class="card box-shadow">
                    <div class="card-header">
                       Edit Book
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-6 mx-auto">
                                <form action="{{ route('book.update', ['id' => $book->id])  }}" method="post" class="form form-shadow" enctype="multipart/form-data">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label for="isbn">ISBN Number</label>
                                        <input type="text" name="isbn" class="form-control" value="{{$book->isbn}}">
                                    </div>

                                    <div class="form-group">
                                        <label for="title">Title</label>
                                        <input type="text" name="title" class="form-control" value="{{$book->title}}">
                                    </div>

                                    <div class="form-group">
                                        <label for="author">Author</label>
                                        <input type="text" name="author" class="form-control" value="{{$book->author}}">
                                    </div>


                                    <div class="form-group">
                                        <label for="edition">Edition</label>
                                        <input type="text" name="edition" class="form-control" value="{{$book->edition}}">
                                    </div>

                                    <div class="form-group">
                                        <label for="edition_year">Edition Year</label>
                                        <input type="date" name="edition_year" class="form-control" value="{{$book->edition_year}}">
                                    </div>

                                    <div class="form-group">
                                        <label for="publisher">Publisher</label>
                                        <input type="text" name="publisher" class="form-control" value="{{$book->publisher}}">
                                    </div>


                                    <div class="form-group">
                                        <label for="total_pages">Total Pages</label>
                                        <input type="number" name="total_pages" class="form-control" value="{{$book->total_pages}}">
                                    </div>


                                    <div class="form-group">
                                        <label for="price">price</label>
                                        <input type="number" name="price" class="form-control" value="{{$book->price}}">
                                    </div>

                                    <div class="form-group">
                                        <label for="notes">Notes</label>
                                        <textarea class="form-control" name="notes">{{$book->notes}}</textarea>
                                    </div>


                                    <div class="form-group">
                                        <label for="genre">Genre</label>
                                        <select name="genre" class="form-control">

                                            @foreach($genres as $g)
                                                <option value="{{$g->id}}" @if($g->id == $book->category_id) selected @endif >{{$g->name}}</option>
                                            @endforeach

                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="quantity">Quantity</label>
                                        <input type="number" name="quantity" class="form-control" value="{{$book->stock->stock}}">
                                    </div>

                                    <div class="form-group">
                                        <label for="images">Images</label>
                                        <input type="file" name="images[]" class="form-control" multiple>
                                    </div>

                                    <div class="form-group">
                                        <input type="submit" value="Update Book" class="btn btn-success float-right">
                                    </div>
                                </form>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>

@endsection
