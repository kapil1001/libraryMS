@extends('layouts.app')

@section('content')
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                       Book Section
                    </div>

                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                    <form action="{{route('book.search')}}" method="get">
                                        <div class="form-row">
                                            <div class="col-sm-6">
                                                <input type="text" name="title" placeholder="Search Book" class="form-control">
                                            </div>
                                            <div class="col-sm-6">
                                                <input type="submit" value="Search" class="btn btn-success">
                                            </div>
                                        </div>
                                    </form>
                            </div>
                            <div class="col-md-6">
                                <a href="{{route('book.create')}}" class="btn btn-info text-light float-right">Add Book</a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 mx-auto table-responsive table-sm">
                                <table class="table table-bordered table-stripped">
                                    <thead  class="thead-dark">
                                        <tr>
                                            <th>S.N</th>
                                            <th>Genre</th>
                                            <th>ISBN</th>
                                            <th>Title</th>
                                            <th>Author</th>
                                            <th>Edition</th>
                                            <th>publisher</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                            @php $i = 1;  @endphp

                                        @if(count($books) > 0)
                                            @foreach($books as $b)
                                                <tr>
                                                    <td>{{$i}}</td>
                                                    <td>{{$b->genre->name}}</td>
                                                    <td>{{$b->isbn}}</td>
                                                    <td>{{$b->title}}</td>
                                                    <td>{{$b->author}}</td>
                                                    <td>{{$b->edition. " (".$b->edition_year.")"}}</td>
                                                    <td>{{$b->publisher}}</td>
                                                    <td>
                                                        @if($b->stock->borrowed < $b->stock->stock)
                                                            <button class="btn btn-success btn-sm disabled">Available</button>
                                                        @else
                                                            <button class="btn btn-danger btn-sm disabled">Not Available</button>
                                                        @endif
                                                    </td>
                                                    <td>
                                                        <a href="{{route('book.details', ['id' => $b->id])}}" class="btn btn-danger btn-sm text-light m-1">View</a>
                                                        <a href="{{route('book.edit', ['id' => $b->id])}}" class="btn btn-info btn-sm text-light m-1">Edit</a>
                                                        <a href="{{route('book.delete', ['id' => $b->id])}}" class="btn btn-danger btn-sm text-light m-1">Delete</a>
                                                    </td>
                                                </tr>
                                                @php $i++;  @endphp
                                            @endforeach
                                        @else
                                            <tr><td class="text-center text-danger" colspan="8">No Book Yet</td></tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
@endsection
