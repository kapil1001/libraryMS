@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card box-shadow">
                <div class="card-header">
                    Book Details
                </div>

                <div class="card-body">

                    <div class="row">
                        <div class="col-md-10 mx-auto p-0 card border border-info my-5">
                            <div class="card-header bg-success">
                                <h3 class="text-center text-light">{{$book->title}}</h3>
                            </div>
                            <div class="card-body table-responsive">
                                <div class="col d-flex justify-content-center">
                                    @foreach($book->images as $image)
                                        <a href="{{asset('storage/images/book/'.$image->image)}}" target="_blank"><img src="{{asset('storage/images/book/'.$image->image)}}" alt="" style="height:150px; width:150px;" class="img-thumbnail p-2 m-3"></a>
                                    @endforeach
                                </div>
                                <table class="table table-borderless table-striped border border-success">
                                    <tbody>
                                        <tr>
                                            <th>Title</th>
                                            <td>{{$book->title}}</td>
                                            <th>ISBN No</th>
                                            <td>{{$book->isbn}}</td>
                                        </tr>

                                        <tr>
                                            <th>Author</th>
                                            <td>{{$book->author}}</td>
                                            <th>Edition</th>
                                            <td>{{$book->edition}}</td>
                                        </tr>

                                        <tr>
                                            <th>Edition Year</th>
                                            <td>{{$book->edition_year}}</td>
                                            <th>Publisher</th>
                                            <td>{{$book->publisher}}</td>
                                        </tr>

                                        <tr>
                                            <th>Total Pages</th>
                                            <td>{{$book->total_pages}}</td>
                                            <th>Price</th>
                                            <td>{{$book->Price}}</td>
                                        </tr>

                                        <tr>
                                            <th>Notes</th>
                                            <td colspan="3">{{$book->notes}}</td>
                                        </tr>

                                        <tr>
                                            <th>Genre</th>
                                            <td>{{$book->genre->name}}</td>
                                            <th>Total Quantity</th>
                                            <td>{{$book->stock->stock}}</td>
                                        </tr>
                                        <tr>
                                            <th>Borrowed</th>
                                            <td>{{$book->stock->borrowed}}</td>
                                            <th>Status</th>
                                            <td>
                                                @if($book->stock->borrowed < $book->stock->stock)
                                                    <button class="btn btn-success btn-sm disabled">Available</button>
                                                @else
                                                    <button class="btn btn-danger btn-sm disabled">Not Available</button>
                                                @endif
                                            </td>

                                        </tr>

                                    </tbody>
                                </table>
                            </div>
                            <div class="card-footer bg-secondary d-flex justify-content-center">

                                <a href="{{route('book.issued.borrower', ['id' => $book->id])}}" class="btn btn-success btn-sm text-light m-1 px-3">Borrowers</a>
                                <a href="{{route('book.edit', ['id' => $book->id])}}" class="btn btn-info btn-sm text-light m-1 px-3">Edit</a>
                                <a href="{{route('book.delete', ['id' => $book->id])}}" class="btn btn-danger btn-sm text-light px-2 m-1">Delete</a>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
@endsection
