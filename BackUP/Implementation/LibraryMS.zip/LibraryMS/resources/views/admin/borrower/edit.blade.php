@extends('layouts.app')

@section('content')

        <div class="row">
            <div class="col-md-12">
                <div class="card box-shadow">
                    <div class="card-header">
                       Edit Borrower
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-12 d-flex justify-content-center">
                                <a href="{{asset('storage/images/identity/'.$borrower->profile->id_image)}}"> <img src="{{asset('storage/images/identity/'.$borrower->profile->id_image)}}" style="height: 150px; width: 150px" alt="" class="p-2 m-4 img-thumbnail"></a>

                                <a href="{{asset('storage/images/borrower/'.$borrower->profile->image)}}"> <img src="{{asset('storage/images/borrower/'.$borrower->profile->image)}}" style="height: 150px; width: 150px" alt="" class="p-2 m-4 img-thumbnail"></a>
                            </div>
                            <div class="col-md-6 mx-auto">
                                <form action="{{ route('borrower.update', ['id' => $borrower->id])}}" method="post" class="form form-shadow" enctype="multipart/form-data">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label for="name">Full Name</label>
                                        <input type="text" name="name" class="form-control" value="{{$borrower->name}}">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" name="email" class="form-control" value="{{$borrower->email}}">
                                    </div>

                                    <div class="form-group">
                                        <label for="phone">Phone</label>
                                        <input type="number" name="phone" class="form-control" value="{{$borrower->profile->phone}}">
                                    </div>


                                    <div class="form-group">
                                        <label for="address">Address</label>
                                        <input type="text" name="address" class="form-control" value="{{$borrower->profile->address}}">
                                    </div>

                                    <div class="form-group">
                                        <label for="dob">Date of Birth</label>
                                        <input type="date" name="dob" class="form-control" value="{{$borrower->profile->dob}}">
                                    </div>

                                    <div class="form-group">
                                        <label for="id_type">Identity Type</label>
                                        <select name="id_type" class="form-control">
                                            <option value="citizenship" @if($borrower->profile->id_type == "citizenship") selected @endif>Citizenship</option>
                                            <option value="license" @if($borrower->profile->id_type == "license") selected @endif>License</option>
                                            <option value="passport" @if($borrower->profile->id_type == "passport") selected @endif>Passport</option>
                                            <option value="student_id" @if($borrower->profile->id_type == "student_id") selected @endif>Student ID</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="id_number">Identity Number</label>
                                        <input type="text" name="id_number" class="form-control" value="{{$borrower->profile->id_number}}">
                                    </div>


                                    <div class="form-group">
                                        <label for="id_image">Identity New Image</label>
                                        <input type="file" name="id_image" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label for="image">Member New Image</label>
                                        <input type="file" name="image" class="form-control">
                                    </div>


                                    <div class="form-group">
                                        <input type="submit" value="Update Borrower" class="btn btn-success float-right">
                                    </div>
                                </form>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>

@endsection
