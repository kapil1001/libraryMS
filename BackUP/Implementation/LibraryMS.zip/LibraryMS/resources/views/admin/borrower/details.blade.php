@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card box-shadow">
                <div class="card-header">
                    Borrower Details
                </div>

                <div class="card-body">

                    <div class="row">
                        <div class="col-md-10 mx-auto p-0 card border border-info my-5">
                            <div class="card-header bg-success">
                                <h3 class="text-center text-light">{{$borrower->name}}</h3>
                            </div>
                            <div class="card-body table-responsive">
                                <div class="col d-flex justify-content-center">

                                        <a href="{{asset('storage/images/identity/'.$borrower->profile->id_image)}}" target="_blank"><img src="{{asset('storage/images/identity/'.$borrower->profile->id_image)}}" alt="" style="height:150px; width:150px;" class="img-thumbnail p-2 m-3"></a>
                                        <a href="{{asset('storage/images/borrower/'.$borrower->profile->image)}}" target="_blank"><img src="{{asset('storage/images/borrower/'.$borrower->profile->image)}}" alt="" style="height:150px; width:150px;" class="img-thumbnail p-2 m-3"></a>

                                </div>
                                <table class="table table-borderless table-striped border border-success">
                                    <tbody>
                                        <tr>
                                            <th>Name</th>
                                            <td>{{$borrower->name}}</td>
                                            <th>Email</th>
                                            <td>{{$borrower->email}}</td>
                                        </tr>

                                        <tr>
                                            <th>Phone</th>
                                            <td>{{$borrower->profile->phone}}</td>
                                            <th>Address</th>
                                            <td>{{$borrower->profile->address}}</td>
                                        </tr>

                                        <tr>
                                            <th>DOB</th>
                                            <td>{{$borrower->profile->dob}}</td>
                                            <th>Identity Type</th>
                                            <td>{{$borrower->profile->id_type}}</td>
                                        </tr>

                                        <tr>
                                            <th>Identity Number</th>
                                            <td colspan="3">{{$borrower->profile->id_number}}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="card-footer bg-secondary d-flex justify-content-center">

                                <a href="{{route('borrower.books.borrowed', ['id' => $borrower->id])}}" class="btn btn-success btn-sm text-light m-1 px-3">Books Borrowed</a>
                                <a href="{{route('borrower.edit', ['id' => $borrower->id])}}" class="btn btn-info btn-sm text-light m-1 px-3">Edit</a>
                                <a href="{{route('borrower.delete', ['id' => $borrower->id])}}" class="btn btn-danger btn-sm text-light px-2 m-1">Delete</a>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
@endsection
