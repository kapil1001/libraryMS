@extends('layouts.app')

@section('content')
        <div class="row">
            <div class="col-md-12">
                <div class="card box-shadow">
                    <div class="card-header">
                        Add Borrower
                   </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-6 mx-auto">
                                <form action="{{ route('borrower.store')}}" method="post" class="form form-shadow" enctype="multipart/form-data">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label for="name">Full Name</label>
                                        <input type="text" name="name" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" name="email" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label for="phone">Phone</label>
                                        <input type="number" name="phone" class="form-control">
                                    </div>


                                    <div class="form-group">
                                        <label for="address">Address</label>
                                        <input type="text" name="address" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label for="dob">Date of Birth</label>
                                        <input type="date" name="dob" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label for="id_type">Identity Type</label>
                                        <select name="id_type" class="form-control">
                                            <option value="0" selected disabled>Select ID Type</option>
                                            <option value="citizenship">Citizenship</option>
                                            <option value="license">License</option>
                                            <option value="passport">Passport</option>
                                            <option value="student_id">Student ID</option>
                                        </select>
                                    </div>


                                    <div class="form-group">
                                        <label for="id_number">Identity Number</label>
                                        <input type="text" name="id_number" class="form-control">
                                    </div>


                                    <div class="form-group">
                                        <label for="id_image">Identity Image</label>
                                        <input type="file" name="id_image" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label for="image">Member Image</label>
                                        <input type="file" name="image" class="form-control">
                                    </div>


                                    <div class="form-group">
                                        <input type="submit" value="Add Borrower" class="btn btn-success float-right">
                                    </div>
                                </form>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
@endsection
