@extends('layouts.app')

@section('content')
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                       Late Return Section
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 mx-auto table-responsive table-sm">
                                <table class="table table-bordered table-stripped">
                                    <thead  class="thead-dark">
                                        <tr>
                                            <th>S.N</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Details</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                            @php $i = 1;  @endphp

                                        @if(count($late_borrowers) > 0)
                                            @foreach($late_borrowers as $b)
                                                <tr>
                                                    <td>{{$i}}</td>
                                                    <td>{{$b->name}}</td>
                                                    <td>{{$b->email}}</td>
                                                    <td>{{$b->profile->phone}}</td>
                                                    <td>
                                                        @php
                                                            $borrowings = $b->book_user;
                                                        @endphp
                                                        @foreach($borrowings as $borrow)
                                                            @php $book = $borrow->book; @endphp
                                                            @php $fine = $borrow->fine; @endphp
                                                            <p><i class="fas fa-book"></i> {{ " " .$book->title ." ( Late Days: ".$fine->late_days_count." & Fine: ".$fine->amount_accrued." )" }}</p>
                                                        @endforeach

                                                    </td>
                                                    <td>
                                                        <a href="{{route('late.send.mail', ['borrower_id' => $b->id])}}" class="btn btn-sm btn-info">Send Mail</a>
                                                    </td>
                                                </tr>
                                                @php $i++;  @endphp
                                            @endforeach
                                        @else
                                            <tr><td class="text-center text-danger" colspan="7">No Borrower Yet</td></tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
@endsection
