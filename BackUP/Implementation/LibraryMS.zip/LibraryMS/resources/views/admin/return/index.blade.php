@extends('layouts.app')

@section('content')
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                       Return Section
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 my-2">
                                <form action="{{route('return.search')}}" method="get">
                                    <div class="form-row">
                                        <div class="col-sm-6">
                                            <input type="text" name="name" placeholder="Search Borrower" class="form-control">
                                        </div>
                                        <div class="col-sm-6">
                                            <input type="submit" value="Search" class="btn btn-success">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 mx-auto table-responsive table-sm">
                                <table class="table table-bordered table-stripped">
                                    <thead  class="thead-dark">
                                        <tr>
                                            <th>S.N</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>DOB</th>
                                            <th>ID Detail</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                            @php $i = 1;  @endphp

                                        @if(count($borrowers) > 0)
                                            @foreach($borrowers as $b)
                                                <tr>
                                                    <td>{{$i}}</td>
                                                    <td>{{$b->name}}</td>
                                                    <td>{{$b->email}}</td>
                                                    <td>{{$b->profile->phone}}</td>
                                                    <td>{{$b->profile->dob}}</td>
                                                    <td>{{$b->profile->id_type. " (".$b->profile->id_number.")"}}</td>
                                                    <td>
                                                        <a href="{{route('return.borrower.book', ['id' => $b->id])}}" class="btn btn-info btn-sm text-light m-1">Return</a>
                                                    </td>
                                                </tr>
                                                @php $i++;  @endphp
                                            @endforeach
                                        @else
                                            <tr><td class="text-center text-danger" colspan="7">No Borrower Yet</td></tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
@endsection
