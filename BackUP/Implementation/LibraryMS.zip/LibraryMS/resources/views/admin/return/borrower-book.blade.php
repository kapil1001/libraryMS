@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-12 card">
            <div class="card-header">
                Books Return section
            </div>

            <div class="card-body">
                <div class="row">
                    <div class="col-md-8 card">
                        <div class="card-header bg-success">
                            <h5 class="text-center text-light">Books Borrowed By {{$borrower->name}}</h5>
                        </div>
                        <div class="card-body table-responsive table-sm">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr class="thead-dark">
                                        <th>S.N</th>
                                        <th>Genre</th>
                                        <th>ISBN</th>
                                        <th>Title</th>
                                        <th>Author</th>
                                        <th>Edition</th>
                                        <th>publisher</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                @if(count($books_borrowed) > 0)
                                    @php $i = 1; @endphp
                                    @foreach($books_borrowed as $bb)
                                        @php
                                            $b = $bb->book;
                                            $fine = $bb->fine;
                                        @endphp
                                        <tr class="@if(!empty($fine)) @if($fine->payment_status == 0) {{"bg-danger text-light"}} @endif  @endif">
                                            <td>{{$i}}</td>
                                            <td>{{$b->genre->name}}</td>
                                            <td>{{$b->isbn}}</td>
                                            <td>{{$b->title}}</td>
                                            <td>{{$b->author}}</td>
                                            <td>{{$b->edition. " (".$b->edition_year.")"}}</td>
                                            <td>{{$b->publisher}}</td>
                                            <td>
                                                @if(!empty($fine))
                                                    @if($fine->payment_status == 1)
                                                        <a href="{{route('return.borrower.single', ['id' => $bb->id])}}" class="btn btn-sm btn-success">Return</a>
                                                    @endif
                                                @else
                                                    <a href="{{route('return.borrower.single', ['id' => $bb->id])}}" class="btn btn-sm btn-success">Return</a>
                                                @endif
                                            </td>
                                        </tr>
                                        @php $i++;  @endphp
                                    @endforeach
                                @else
                                    <tr><td class="text-center text-danger" colspan="9">No Books Borrowed</td></tr>
                                @endif
                                </tbody>
                            </table>
                            <div class="card-footer">
                                <a href="{{route('return.borrower.all', ['borrower_id' => $borrower->id])}}" class="btn btn-info btn-sm float-right">Return All</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 card">
                        <div class="col- card-header">
                            <h5 class="text-center">Fine Accrued of {{$borrower->name}}</h5>
                        </div>
                        <div class="table-body table-responsive">
                            <table class="table table-sm table-bordered table-hover">
                                <thead class="thead-dark">
                                    <tr>
                                        <th colspan="2">Book</th>
                                        <th>Delayed</th>
                                        <th>Amount</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                            @if(count($borrower_fine))
                                @foreach($borrower_fine as $bf)
                                    <tr>
                                        <td colspan="2">{{$bf->book_user->book->title. " -> ".$bf->book_user->book->author}}</td>
                                        <td>{{$bf->late_days_count}}</td>
                                        <td>{{$bf->amount_accrued}}</td>
                                        <td><a href="{{route('borrower.fine.pay', ['id' => $bf->id])}}" class="btn btn-success btn-sm">Pay</a></td>
                                    </tr>
                                @endforeach
                            @else
                                <tr><td colspan="5" class="text-danger text-center">No Fines</td></tr>
                            @endif
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
@endsection
