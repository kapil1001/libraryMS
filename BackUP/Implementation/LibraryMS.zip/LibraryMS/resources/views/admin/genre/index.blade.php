@extends('layouts.app')

@section('content')
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                       Genre Section
                    </div>

                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-12">
                            <a href="{{route('genre.create')}}" class="btn btn-info text-light float-right">Add Genre</a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-10 mx-auto table-responsive table-sm">
                                <table class="table table-bordered table-stripped">
                                    <thead  class="thead-dark">
                                        <tr>
                                            <th>S.N</th>
                                            <th>Name</th>
                                            <th>Description</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                            @php $i = 1;  @endphp

                                        @if(count($genres) > 0)
                                            @foreach($genres as $g)
                                                <tr>
                                                    <td>{{$i}}</td>
                                                    <td>{{$g->name}}</td>
                                                    <td>{{$g->description}}</td>
                                                    <td><a href="{{route('genre.edit', ['id' => $g->id])}}" class="btn btn-info btn-sm text-light m-1">Edit</a>
                                                    <a href="{{route('genre.delete', ['id' => $g->id])}}" class="btn btn-danger btn-sm text-light m-1">Delete</a></td>
                                                </tr>
                                                @php $i++;  @endphp
                                            @endforeach
                                        @else
                                            <tr><td class="text-center text-danger" colspan="5">No Genre Yet</td></tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
@endsection
