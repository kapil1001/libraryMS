@extends('layouts.app')

@section('content')

        <div class="row">
            <div class="col-md-12">
                <div class="card box-shadow">
                    <div class="card-header">
                       Edit Genre
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-6 mx-auto">
                                <form action="{{ route('genre.update', ['id' => $genre->id]) }}" method="post" class="form form-shadow">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label for="name">Genre Name</label>
                                        <input type="text" name="name" value="{{$genre->name}}" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label for="description">Genre Description</label>
                                        <input type="text" name="description" value="{{$genre->description}}" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <input type="submit" value="Update Genre" class="btn btn-success text-center">
                                    </div>
                                </form>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>

@endsection
