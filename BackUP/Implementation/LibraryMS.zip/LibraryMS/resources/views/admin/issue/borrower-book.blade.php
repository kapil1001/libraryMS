@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-12 card">
                <div class="card-header">
                    Issuing Book To {{$borrower->name}}
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="row d-flex justify-content-between my-2">
                                <div class="col-md-6">
                                    <form action="{{route('issue.book.search-title-author', ['borrower_id' => $borrower_id])}}" method="get" class="form-inline">
                                        <div class="form-group">
                                            <div class="col-">
                                                <input type="text" name="title_author" placeholder="Search Title or Author" class="form-control-sm">
                                            </div>
                                            <div class="col- ml-2">
                                                <input type="submit" value="Search" class="btn btn-sm btn-success">
                                            </div>
                                        </div>
                                    </form>
                                </div>

                                <div class="col-md-4 d-flex justify-content-end">
                                    <form action="{{route('issue.book.filter-genre', ['borrower_id' => $borrower_id])}}" method="get" class="form-inline">
                                        <div class="form-group">
                                            <div class="col-">
                                                <select name="genre" class="form-control-sm">
                                                    <option value="0" selected disabled>Select Genre</option>
                                                    @foreach($genres as $genre)
                                                        <option value="{{$genre->id}}">{{$genre->name}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col- ml-2">
                                                <input type="submit" value="Filter" class="btn btn-sm btn-success">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 table-responsive table-sm">
                                    <table class="table table-bordered">
                                        <thead  class="thead-dark">
                                        <tr>
                                            <th>S.N</th>
                                            <th>Genre</th>
                                            <th>ISBN</th>
                                            <th>Title</th>
                                            <th>Author</th>
                                            <th>Edition</th>
                                            <th>publisher</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @php $i = 1;  @endphp

                                        @if(count($books) > 0)
                                            @foreach($books as $b)
                                                <tr>
                                                    <td>{{$i}}</td>
                                                    <td>{{$b->genre->name}}</td>
                                                    <td>{{$b->isbn}}</td>
                                                    <td>{{$b->title}}</td>
                                                    <td>{{$b->author}}</td>
                                                    <td>{{$b->edition. " (".$b->edition_year.")"}}</td>
                                                    <td>{{$b->publisher}}</td>
                                                    <td>
                                                        @if($b->stock->borrowed < $b->stock->stock)
                                                            <button class="btn btn-success btn-sm">Available</button>
                                                        @else
                                                            <button class="btn btn-danger btn-sm disabled">Not Available</button>
                                                        @endif
                                                    </td>
                                                    <td>
                                                        @if($b->stock->borrowed < $b->stock->stock)
                                                            <a href="{{route('issue.cart.add', ['book_id' => $b->id, 'borrower_id' => $borrower_id])}}" class="btn btn-success btn-sm text-light">Add</a>
                                                        @endif
                                                    </td>
                                                </tr>
                                                @php $i++;  @endphp
                                            @endforeach
                                        @else
                                            <tr><td class="text-center text-danger" colspan="9">No Book Yet</td></tr>
                                        @endif
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="col- card m-0 p-0 mb-3">
                                <div class="card-header bg-danger">
                                    <h5 class="text-center text-light">Borrowed List</h5>
                                </div>
                                <div class="card-body table-responsive table-sm m-0 p-0">
                                    <table class="table table-borderless m-0 p-0">
                                        <thead class="thead-dark">
                                        <tr>
                                            <th>Book Detail</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @if(count($borrowed_list) > 0)
                                            @foreach($borrowed_list as $bl)
                                                <tr>
                                                    <td>{{"Title: ".$bl->book->title." (".$bl->book->genre->name.") -> By: ".$bl->book->author }}</td>
                                                </tr>

                                            @endforeach
                                        @else
                                            <tr><td colspan="4" class="text-danger text-center">No Books Borrowed Yet</td></tr>
                                        @endif
                                        </tbody>
                                    </table>
                                </div>
                                <div class="card-footer bg-secondary">
                                    <a href="" class="btn btn-success btn-sm text-light">Return Section</a>
                                </div>
                            </div>
                            <div class="col- card m-0 p-0 mt-3">
                                <div class="card-header bg-info">
                                    <h5 class="text-center text-light">Issue List</h5>
                                </div>
                                <div class="card-body table-responsive table-sm m-0 p-0">
                                    <table class="table table-borderless m-0 p-0">
                                        <thead class="thead-dark">
                                            <tr>
                                                <th colspan="3">Book Detail</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        @if(count($borrower_cart) > 0)
                                        @foreach($borrower_cart as $bc)
                                            <tr>
                                                <td colspan="3">{{"Title: ".$bc->book->title." (".$bc->book->genre->name.") -> By: ".$bc->book->author }}</td>
                                                <td><a href="{{route('issue.cart.remove', ['id' => $bc->id])}}" class="btn btn-danger btn-sm text-light">Remove</a></td>
                                            </tr>

                                        @endforeach
                                        @else
                                            <tr><td colspan="4" class="text-danger text-center">Issue List Is Empty</td></tr>
                                        @endif
                                        </tbody>
                                    </table>
                                </div>
                                <div class="card-footer bg-secondary">
                                    <div class="col- mb-1 d-flex justify-content-center">
                                        <a href="{{route('issue.cart.clear', ['borrower_id' => $borrower_id])}}" class="btn btn-info btn-sm text-light mx-auto">Clear</a>
                                    </div>
                                    <div class="col- mt-3">
                                        <form action="{{route('issue.cart.check-out', ['borrower_id' => $borrower_id])}}" method="get">
                                            <div class="form-row">
                                                <div class="col-md-3 px-1">
                                                    <label for="borrow_period" class="text-light">Period</label>
                                                </div>
                                                <div class="col-md-7 px-1"><input type="number" name="borrow_period" class="form-control-sm"></div>
                                                <div class="col-md-2 px-1"><input type="submit" value="Issue" class="btn btn-sm btn-success"></div>
                                            </div>
                                        </form>

                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
@endsection
