<?php $__env->startSection('content'); ?>
    <div class="row mx-4">
        <div class="col-md-12">
            <div class="card box-shadow">
                <div class="card-header">
                    Book Create
                </div>

                <div class="card-body">

                    <div class="row">
                        <div class="col-md-6 mx-auto card">
                            <div class="card-header">
                                <h3 class="text-center text-danger"><?php echo e($book->title); ?></h3>
                            </div>
                            <div class="card-body table-responsive">
                                <div class="col d-flex justify-content-around">
                                    <?php $__currentLoopData = $book->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(asset('storage/images/book/'.$image->image)); ?>" alt="" height="150px" width="150px"  class="img-thumbnail p-2 m-3">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <table class="table table-bordered table-hover">
                                    <tbody>
                                        <tr>
                                            <th>Title</th>
                                            <td><?php echo e($book->title); ?></td>
                                            <th>ISBN No</th>
                                            <td><?php echo e($book->isbn); ?></td>
                                        </tr>

                                        <tr>
                                            <th>Author</th>
                                            <td><?php echo e($book->author); ?></td>
                                            <th>Edition</th>
                                            <td><?php echo e($book->edition); ?></td>
                                        </tr>

                                        <tr>
                                            <th>Edition Year</th>
                                            <td><?php echo e($book->edition_year); ?></td>
                                            <th>Publisher</th>
                                            <td><?php echo e($book->publisher); ?></td>
                                        </tr>

                                        <tr>
                                            <th>Total Pages</th>
                                            <td><?php echo e($book->total_pages); ?></td>
                                            <th>Price</th>
                                            <td><?php echo e($book->Price); ?></td>
                                        </tr>

                                        <tr>
                                            <th>Notes</th>
                                            <td colspan="3"><?php echo e($book->notes); ?></td>
                                        </tr>

                                        <tr>
                                            <th>Genre</th>
                                            <td><?php echo e($book->genre->name); ?></td>
                                            <th>Total Quantity</th>
                                            <td><?php echo e($book->stock->stock); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Borrowed</th>
                                            <td><?php echo e($book->stock->borrowed); ?></td>
                                            <th>Status</th>
                                            <td>
                                                <?php if($book->stock->borrowed < $book->stock->stock): ?>
                                                    <button class="btn btn-success btn-sm">Available</button>
                                                <?php else: ?>
                                                    <button class="btn btn-danger btn-sm">Not Available</button>
                                                <?php endif; ?>
                                            </td>

                                        </tr>

                                    </tbody>
                                </table>
                            </div>
                            <div class="card-footer"></div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/admin/book/view.blade.php ENDPATH**/ ?>