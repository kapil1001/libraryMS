<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                       Genre Section
                    </div>

                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-12">
                            <a href="<?php echo e(route('genre.create')); ?>" class="btn btn-info text-light float-right">Add Genre</a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-10 mx-auto table-responsive table-sm">
                                <table class="table table-bordered table-stripped">
                                    <thead  class="thead-dark">
                                        <tr>
                                            <th>S.N</th>
                                            <th>Name</th>
                                            <th>Description</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                            <?php $i = 1;  ?>

                                        <?php if(count($genres) > 0): ?>
                                            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i); ?></td>
                                                    <td><?php echo e($g->name); ?></td>
                                                    <td><?php echo e($g->description); ?></td>
                                                    <td><a href="<?php echo e(route('genre.edit', ['id' => $g->id])); ?>" class="btn btn-info btn-sm text-light m-1">Edit</a>
                                                    <a href="<?php echo e(route('genre.delete', ['id' => $g->id])); ?>" class="btn btn-danger btn-sm text-light m-1">Delete</a></td>
                                                </tr>
                                                <?php $i++;  ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr><td class="text-center text-danger" colspan="5">No Genre Yet</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/admin/genre/index.blade.php ENDPATH**/ ?>