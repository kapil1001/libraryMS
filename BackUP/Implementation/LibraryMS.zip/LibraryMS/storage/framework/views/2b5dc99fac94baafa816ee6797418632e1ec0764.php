<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                       Book Section
                    </div>

                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                    <form action="<?php echo e(route('book.search')); ?>" method="get">
                                        <div class="form-row">
                                            <div class="col-sm-6">
                                                <input type="text" name="title" placeholder="Search Book" class="form-control">
                                            </div>
                                            <div class="col-sm-6">
                                                <input type="submit" value="Search" class="btn btn-success">
                                            </div>
                                        </div>
                                    </form>
                            </div>
                            <div class="col-md-6">
                                <a href="<?php echo e(route('book.create')); ?>" class="btn btn-info text-light float-right">Add Book</a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 mx-auto table-responsive table-sm">
                                <table class="table table-bordered table-stripped">
                                    <thead  class="thead-dark">
                                        <tr>
                                            <th>S.N</th>
                                            <th>Genre</th>
                                            <th>ISBN</th>
                                            <th>Title</th>
                                            <th>Author</th>
                                            <th>Edition</th>
                                            <th>publisher</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                            <?php $i = 1;  ?>

                                        <?php if(count($books) > 0): ?>
                                            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i); ?></td>
                                                    <td><?php echo e($b->genre->name); ?></td>
                                                    <td><?php echo e($b->isbn); ?></td>
                                                    <td><?php echo e($b->title); ?></td>
                                                    <td><?php echo e($b->author); ?></td>
                                                    <td><?php echo e($b->edition. " (".$b->edition_year.")"); ?></td>
                                                    <td><?php echo e($b->publisher); ?></td>
                                                    <td>
                                                        <?php if($b->stock->borrowed < $b->stock->stock): ?>
                                                            <button class="btn btn-success btn-sm disabled">Available</button>
                                                        <?php else: ?>
                                                            <button class="btn btn-danger btn-sm disabled">Not Available</button>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('book.details', ['id' => $b->id])); ?>" class="btn btn-danger btn-sm text-light m-1">View</a>
                                                        <a href="<?php echo e(route('book.edit', ['id' => $b->id])); ?>" class="btn btn-info btn-sm text-light m-1">Edit</a>
                                                        <a href="<?php echo e(route('book.delete', ['id' => $b->id])); ?>" class="btn btn-danger btn-sm text-light m-1">Delete</a>
                                                    </td>
                                                </tr>
                                                <?php $i++;  ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr><td class="text-center text-danger" colspan="8">No Book Yet</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/admin/book/index.blade.php ENDPATH**/ ?>