<?php $__env->startSection('content'); ?>
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Borrower Profile</div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-10 mx-auto p-0 card border border-info">
                                <div class="card-header bg-success">
                                    <h3 class="text-center text-light"><?php echo e($user->name); ?></h3>
                                </div>
                                <div class="card-body table-responsive">
                                    <div class="col d-flex justify-content-center">

                                        <a href="<?php echo e(asset('storage/images/identity/'.$user->profile->id_image)); ?>" target="_blank"><img src="<?php echo e(asset('storage/images/identity/'.$user->profile->id_image)); ?>" alt="" style="height:150px; width:150px;" class="img-thumbnail p-2 m-3"></a>
                                        <a href="<?php echo e(asset('storage/images/borrower/'.$user->profile->image)); ?>" target="_blank"><img src="<?php echo e(asset('storage/images/borrower/'.$user->profile->image)); ?>" alt="" style="height:150px; width:150px;" class="img-thumbnail p-2 m-3"></a>

                                    </div>
                                    <table class="table table-borderless table-striped border border-success">
                                        <tbody>
                                        <tr>
                                            <th>Name</th>
                                            <td><?php echo e($user->name); ?></td>
                                            <th>Email</th>
                                            <td><?php echo e($user->email); ?></td>
                                        </tr>

                                        <tr>
                                            <th>Phone</th>
                                            <td><?php echo e($user->profile->phone); ?></td>
                                            <th>Address</th>
                                            <td><?php echo e($user->profile->address); ?></td>
                                        </tr>

                                        <tr>
                                            <th>DOB</th>
                                            <td><?php echo e($user->profile->dob); ?></td>
                                            <th>Identity Type</th>
                                            <td><?php echo e($user->profile->id_type); ?></td>
                                        </tr>

                                        <tr>
                                            <th>Identity Number</th>
                                            <td colspan="3"><?php echo e($user->profile->id_number); ?></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="card-footer bg-secondary d-flex justify-content-center">
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#changePWModalCenter">
                                       Change Password
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="changePWModalCenter" tabindex="-1" role="dialog" aria-labelledby="changePWModalCenter" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                       <div class="col-md-8 mx-auto">
                           <form action="<?php echo e(route('borrower.password.change')); ?>" method="post">
                               <?php echo e(csrf_field()); ?>

                               <div class="form-group">
                                   <label for="password">Password</label>
                                   <input type="password" name="password" class="form-control">
                               </div>
                               <div class="form-group">
                                   <label for="password_confirmation">Confirm Password</label>
                                   <input type="password" name="password_confirmation" class="form-control">
                               </div>

                               <div class="form-group">
                                   <input type="submit" value="Change Password" class="btn btn-success">
                               </div>
                           </form>
                       </div>
                    </div>

                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-borrower', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/borrower/profile.blade.php ENDPATH**/ ?>