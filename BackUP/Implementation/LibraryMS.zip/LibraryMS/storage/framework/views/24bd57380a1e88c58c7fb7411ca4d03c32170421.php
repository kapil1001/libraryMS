<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Admin Dashboard</div>

                <div class="row d-flex justify-content-center">
                    <div class="col-md-3 m-4">
                        <div class="col- rounded border border-info bg-danger">
                            <h1 class="text-center mt-2"><i class="fas fa-book-dead"></i></h1>
                            <h5 class="text-center text-light font-weight-bold mb-2">Total Books Overdue</h5>
                            <h6 class="text-center text-light font-weight-bold mb-2"> Rs. <?php echo e($total_books_overdue); ?> </h6>
                        </div>
                    </div>
                    <div class="col-md-3 m-4">
                        <div class="col- rounded border border-info bg-info">
                            <h1 class="text-center mt-2"><i class="fas fa-hand-holding-usd"></i></h1>
                            <h5 class="text-center text-light font-weight-bold mb-2">Total Fee Due</h5>
                            <h6 class="text-center text-light font-weight-bold mb-2"> Rs. <?php echo e($total_fee_due); ?> </h6>
                        </div>
                    </div>
                    <div class="col-md-3 m-4">
                        <div class="col- rounded border border-info bg-success">
                            <h1 class="text-center mt-2"><i class="fas fa-wallet"></i></h1>
                            <h5 class="text-center text-light font-weight-bold mb-2">Total Fee Collected</h5>
                            <h6 class="text-center text-light font-weight-bold mb-2"> Rs. <?php echo e($total_fee_collected); ?> </h6>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/admin/home.blade.php ENDPATH**/ ?>