<?php $__env->startSection('content'); ?>

        <div class="row mx-4">
            <div class="col-md-12">
                <div class="card box-shadow">
                    <div class="card-header">
                       Edit Book
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-6 mx-auto">
                                <form action="<?php echo e(route('book.update', ['id' => $book->id])); ?>" method="post" class="form form-shadow" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <label for="isbn">ISBN Number</label>
                                        <input type="text" name="isbn" class="form-control" value="<?php echo e($book->isbn); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="title">Title</label>
                                        <input type="text" name="title" class="form-control" value="<?php echo e($book->title); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="author">Author</label>
                                        <input type="text" name="author" class="form-control" value="<?php echo e($book->author); ?>">
                                    </div>


                                    <div class="form-group">
                                        <label for="edition">Edition</label>
                                        <input type="text" name="edition" class="form-control" value="<?php echo e($book->edition); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="edition_year">Edition Year</label>
                                        <input type="date" name="edition_year" class="form-control" value="<?php echo e($book->edition_year); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="publisher">Publisher</label>
                                        <input type="text" name="publisher" class="form-control" value="<?php echo e($book->publisher); ?>">
                                    </div>


                                    <div class="form-group">
                                        <label for="total_pages">Total Pages</label>
                                        <input type="number" name="total_pages" class="form-control" value="<?php echo e($book->total_pages); ?>">
                                    </div>


                                    <div class="form-group">
                                        <label for="price">price</label>
                                        <input type="number" name="price" class="form-control" value="<?php echo e($book->price); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="notes">Notes</label>
                                        <textarea class="form-control" name="notes"><?php echo e($book->notes); ?></textarea>
                                    </div>


                                    <div class="form-group">
                                        <label for="genre">Genre</label>
                                        <select name="genre" class="form-control">

                                            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($g->id); ?>" <?php if($g->id == $book->category_id): ?> selected <?php endif; ?> ><?php echo e($g->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="quantity">Quantity</label>
                                        <input type="number" name="quantity" class="form-control" value="<?php echo e($book->stock->stock); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="images">Images</label>
                                        <input type="file" name="images[]" class="form-control" multiple>
                                    </div>

                                    <div class="form-group">
                                        <input type="submit" value="Update Book" class="btn btn-success float-right">
                                    </div>
                                </form>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/admin/book/edit.blade.php ENDPATH**/ ?>