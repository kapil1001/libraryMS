<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 card">
            <div class="card-header">
                Books Return section
            </div>

            <div class="card-body">
                <div class="row">
                    <div class="col-md-8 card">
                        <div class="card-header bg-success">
                            <h5 class="text-center text-light">Books Borrowed By <?php echo e($borrower->name); ?></h5>
                        </div>
                        <div class="card-body table-responsive table-sm">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr class="thead-dark">
                                        <th>S.N</th>
                                        <th>Genre</th>
                                        <th>ISBN</th>
                                        <th>Title</th>
                                        <th>Author</th>
                                        <th>Edition</th>
                                        <th>publisher</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php if(count($books_borrowed) > 0): ?>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $books_borrowed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $b = $bb->book;
                                            $fine = $bb->fine;
                                        ?>
                                        <tr class="<?php if(!empty($fine)): ?> <?php if($fine->payment_status == 0): ?> <?php echo e("bg-danger text-light"); ?> <?php endif; ?>  <?php endif; ?>">
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($b->genre->name); ?></td>
                                            <td><?php echo e($b->isbn); ?></td>
                                            <td><?php echo e($b->title); ?></td>
                                            <td><?php echo e($b->author); ?></td>
                                            <td><?php echo e($b->edition. " (".$b->edition_year.")"); ?></td>
                                            <td><?php echo e($b->publisher); ?></td>
                                            <td>
                                                <?php if(!empty($fine)): ?>
                                                    <?php if($fine->payment_status == 1): ?>
                                                        <a href="<?php echo e(route('return.borrower.single', ['id' => $bb->id])); ?>" class="btn btn-sm btn-success">Return</a>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('return.borrower.single', ['id' => $bb->id])); ?>" class="btn btn-sm btn-success">Return</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php $i++;  ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr><td class="text-center text-danger" colspan="9">No Books Borrowed</td></tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <div class="card-footer">
                                <a href="<?php echo e(route('return.borrower.all', ['borrower_id' => $borrower->id])); ?>" class="btn btn-info btn-sm float-right">Return All</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 card">
                        <div class="col- card-header">
                            <h5 class="text-center">Fine Accrued of <?php echo e($borrower->name); ?></h5>
                        </div>
                        <div class="table-body table-responsive">
                            <table class="table table-sm table-bordered table-hover">
                                <thead class="thead-dark">
                                    <tr>
                                        <th colspan="2">Book</th>
                                        <th>Delayed</th>
                                        <th>Amount</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                            <?php if(count($borrower_fine)): ?>
                                <?php $__currentLoopData = $borrower_fine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="2"><?php echo e($bf->book_user->book->title. " -> ".$bf->book_user->book->author); ?></td>
                                        <td><?php echo e($bf->late_days_count); ?></td>
                                        <td><?php echo e($bf->amount_accrued); ?></td>
                                        <td><a href="<?php echo e(route('borrower.fine.pay', ['id' => $bf->id])); ?>" class="btn btn-success btn-sm">Pay</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr><td colspan="5" class="text-danger text-center">No Fines</td></tr>
                            <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/admin/return/borrower-book.blade.php ENDPATH**/ ?>