<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center welcome-bg">
        <div class="col- dark-overlay">
            <div class="col-md-12">
                <h1 class="text-center text-light margin-label">Welcome To Library Management System</h1>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-borrower', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/welcome.blade.php ENDPATH**/ ?>