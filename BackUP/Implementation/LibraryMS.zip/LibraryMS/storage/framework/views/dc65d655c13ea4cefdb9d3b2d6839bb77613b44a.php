<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">User Section</div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                            <a href="<?php echo e(route('user.create')); ?>" class="btn btn-info text-light float-right">Create User</a>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-8 mx-auto table-responsive table-sm">
                                <table class="table table-bordered table-stripped">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>S.N</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(count($users) > 0): ?>
                                        <?php $i = 1 ?>

                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                                <td><?php echo e($i); ?></td>
                                                <td><?php echo e($user->name); ?></td>
                                                <td><?php echo e($user->email); ?></td>
                                                <td>
                                                    <?php if(Auth::user()->id != $user->id): ?>
                                                    <a href="<?php echo e(route('user.delete', ['id' => $user->id])); ?>" class="btn btn-danger btn-sm">Delete</a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php $i++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr><td colspan="4" class="text-danger text-center">No users yet</td></tr>

                                    <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/admin/user/index.blade.php ENDPATH**/ ?>