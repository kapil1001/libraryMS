<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                       Issue Section
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 my-2">
                                <form action="<?php echo e(route('issue.search')); ?>" method="get">
                                    <div class="form-row">
                                        <div class="col-sm-6">
                                            <input type="text" name="name" placeholder="Search Borrower" class="form-control">
                                        </div>
                                        <div class="col-sm-6">
                                            <input type="submit" value="Search" class="btn btn-success">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 mx-auto table-responsive table-sm">
                                <table class="table table-bordered table-stripped">
                                    <thead  class="thead-dark">
                                        <tr>
                                            <th>S.N</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>DOB</th>
                                            <th>ID Detail</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                            <?php $i = 1;  ?>

                                        <?php if(count($borrowers) > 0): ?>
                                            <?php $__currentLoopData = $borrowers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i); ?></td>
                                                    <td><?php echo e($b->name); ?></td>
                                                    <td><?php echo e($b->email); ?></td>
                                                    <td><?php echo e($b->profile->phone); ?></td>
                                                    <td><?php echo e($b->profile->dob); ?></td>
                                                    <td><?php echo e($b->profile->id_type. " (".$b->profile->id_number.")"); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(route('issue.borrower.book', ['id' => $b->id])); ?>" class="btn btn-info btn-sm text-light m-1">Issue</a>
                                                    </td>
                                                </tr>
                                                <?php $i++;  ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr><td class="text-center text-danger" colspan="7">No Borrower Yet</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/admin/issue/index.blade.php ENDPATH**/ ?>