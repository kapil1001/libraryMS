<?php $__env->startSection('content'); ?>

        <div class="row mx-4">
            <div class="col-md-12">
                <div class="card box-shadow">
                    <div class="card-header">
                       Edit Genre
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-6 mx-auto">
                                <form action="<?php echo e(route('genre.update', ['id' => $genre->id])); ?>" method="post" class="form form-shadow">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <label for="name">Genre Name</label>
                                        <input type="text" name="name" value="<?php echo e($genre->name); ?>" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label for="description">Genre Description</label>
                                        <input type="text" name="description" value="<?php echo e($genre->description); ?>" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <input type="submit" value="Update Genre" class="btn btn-success text-center">
                                    </div>
                                </form>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/admin/genre/edit.blade.php ENDPATH**/ ?>