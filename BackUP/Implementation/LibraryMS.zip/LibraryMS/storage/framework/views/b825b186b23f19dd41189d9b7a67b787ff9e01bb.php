<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">User Profile of <?php echo e(Auth::user()->name); ?></div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-6 mx-auto">
                                <form action="<?php echo e(route('user.profile.update')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <h4 class="text-center text-info">Your Profile Details</h4>
                                    <div class="form-group">
                                        <label for="email">Name</label>
                                        <input type="text" name="name" value="<?php echo e(Auth::user()->name); ?>" class="form-control" autocomplete="off">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">User Email</label>
                                        <input type="email" name="email" value="<?php echo e(Auth::user()->email); ?>" class="form-control" autocomplete="off">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">New Password</label>
                                        <input type="password" name="password" class="form-control" autocomplete="off">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Confirm Password</label>
                                        <input type="password" name="password_confirmation" class="form-control" autocomplete="off">
                                    </div>

                                    <div class="form-group">
                                        <input type="submit" name="update_user" value="Update Profile" class="btn btn-success float-right">
                                    </div>
                                </form>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/admin/user/profile.blade.php ENDPATH**/ ?>