<?php $__env->startSection('content'); ?>
    <div class="row mx-4">
        <div class="col-md-12">
            <div class="card box-shadow">
                <div class="card-header">
                    Borrower Details
                </div>

                <div class="card-body">

                    <div class="row">
                        <div class="col-md-10 mx-auto p-0 card border border-info my-5">
                            <div class="card-header bg-success">
                                <h3 class="text-center text-light"><?php echo e($borrower->name); ?></h3>
                            </div>
                            <div class="card-body table-responsive">
                                <div class="col d-flex justify-content-center">

                                        <a href="<?php echo e(asset('storage/images/identity/'.$borrower->profile->id_image)); ?>" target="_blank"><img src="<?php echo e(asset('storage/images/identity/'.$borrower->profile->id_image)); ?>" alt="" style="height:150px; width:150px;" class="img-thumbnail p-2 m-3"></a>
                                        <a href="<?php echo e(asset('storage/images/borrower/'.$borrower->profile->image)); ?>" target="_blank"><img src="<?php echo e(asset('storage/images/borrower/'.$borrower->profile->image)); ?>" alt="" style="height:150px; width:150px;" class="img-thumbnail p-2 m-3"></a>

                                </div>
                                <table class="table table-borderless table-striped border border-success">
                                    <tbody>
                                        <tr>
                                            <th>Name</th>
                                            <td><?php echo e($borrower->name); ?></td>
                                            <th>Email</th>
                                            <td><?php echo e($borrower->email); ?></td>
                                        </tr>

                                        <tr>
                                            <th>Phone</th>
                                            <td><?php echo e($borrower->profile->phone); ?></td>
                                            <th>Address</th>
                                            <td><?php echo e($borrower->profile->address); ?></td>
                                        </tr>

                                        <tr>
                                            <th>DOB</th>
                                            <td><?php echo e($borrower->profile->dob); ?></td>
                                            <th>Identity Type</th>
                                            <td><?php echo e($borrower->profile->id_type); ?></td>
                                        </tr>

                                        <tr>
                                            <th>Identity Number</th>
                                            <td colspan="3"><?php echo e($borrower->profile->id_number); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="card-footer bg-secondary d-flex justify-content-center">

                                <a href="<?php echo e(route('borrower.books.borrowed', ['id' => $borrower->id])); ?>" class="btn btn-success btn-sm text-light m-1 px-3">Books Borrowed</a>
                                <a href="<?php echo e(route('borrower.edit', ['id' => $borrower->id])); ?>" class="btn btn-info btn-sm text-light m-1 px-3">Edit</a>
                                <a href="<?php echo e(route('borrower.delete', ['id' => $borrower->id])); ?>" class="btn btn-danger btn-sm text-light px-2 m-1">Delete</a>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/admin/borrower/details.blade.php ENDPATH**/ ?>