<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card box-shadow">
                <div class="card-header">
                    Borrower Details
                </div>

                <div class="card-body">

                    <div class="row">
                        <div class="col-md-12 mx-auto p-0 card border border-info">
                            <div class="card-header bg-success">
                                <h5 class="text-center text-light">Books Borrowed by <?php echo e($borrower->name); ?></h5>
                            </div>
                            <div class="card-body table-responsive">
                                    <table class="table table-bordered table-stripped">
                                        <thead  class="thead-dark">
                                        <tr>
                                            <th>S.N</th>
                                            <th>Genre</th>
                                            <th>ISBN</th>
                                            <th>Title</th>
                                            <th>Author</th>
                                            <th>Edition</th>
                                            <th>publisher</th>
                                            <th>Borrow Date</th>
                                            <th>Due Date</th>
                                            <th>Arrears Days</th>
                                            <th>Accrued Fine</th>

                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $i = 1;  ?>

                                        <?php if(count($borrowings) > 0): ?>
                                            <?php $__currentLoopData = $borrowings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrowing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $book = $borrowing->book;
                                                    $fine = $borrowing->fine;
                                                    $date=date_create($borrowing->borrowed_date);
                                                    date_add($date,date_interval_create_from_date_string($borrowing->borrow_period." days"));
                                                    $return_date = date_format($date,"Y-m-d");
                                                ?>
                                                <tr>
                                                    <td><?php echo e($i); ?></td>
                                                    <td><?php echo e($book->genre->name); ?></td>
                                                    <td><?php echo e($book->isbn); ?></td>
                                                    <td><?php echo e($book->title); ?></td>
                                                    <td><?php echo e($book->author); ?></td>
                                                    <td><?php echo e($book->edition. " (".$book->edition_year.")"); ?></td>
                                                    <td><?php echo e($book->publisher); ?></td>
                                                    <td><?php echo e($borrowing->borrowed_date); ?></td>
                                                    <td><?php echo e($return_date); ?></td>
                                                    <td>
                                                        <?php if(!empty($fine)): ?>
                                                            <?php echo e($fine->late_days_count); ?>

                                                        <?php else: ?>
                                                            <?php echo e(NA); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if(!empty($fine)): ?>
                                                            <?php echo e($fine->amount_accrued); ?>

                                                        <?php else: ?>
                                                            <?php echo e(NA); ?>

                                                        <?php endif; ?>
                                                    </td>

                                                </tr>
                                                <?php $i++;  ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr><td class="text-center text-danger" colspan="7">No Book Borrowed Yet</td></tr>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                            </div>
                            <div class="card-footer">
                                <?php if(count($borrowings) > 0): ?>
                                    <a href="<?php echo e(route('return.borrower.book', ['borrower_id' => $borrower->id])); ?>" class="btn btn-success">Return Book</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/admin/borrower/books-borrowers.blade.php ENDPATH**/ ?>