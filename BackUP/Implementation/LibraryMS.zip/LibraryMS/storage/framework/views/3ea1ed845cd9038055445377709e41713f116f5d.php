<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                       Late Return Section
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 mx-auto table-responsive table-sm">
                                <table class="table table-bordered table-stripped">
                                    <thead  class="thead-dark">
                                        <tr>
                                            <th>S.N</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Details</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                            <?php $i = 1;  ?>

                                        <?php if(count($late_borrowers) > 0): ?>
                                            <?php $__currentLoopData = $late_borrowers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i); ?></td>
                                                    <td><?php echo e($b->name); ?></td>
                                                    <td><?php echo e($b->email); ?></td>
                                                    <td><?php echo e($b->profile->phone); ?></td>
                                                    <td>
                                                        <?php
                                                            $borrowings = $b->book_user;
                                                        ?>
                                                        <?php $__currentLoopData = $borrowings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $book = $borrow->book; ?>
                                                            <?php $fine = $borrow->fine; ?>
                                                            <p><i class="fas fa-book"></i> <?php echo e(" " .$book->title ." ( Late Days: ".$fine->late_days_count." & Fine: ".$fine->amount_accrued." )"); ?></p>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('late.send.mail', ['borrower_id' => $b->id])); ?>" class="btn btn-sm btn-info">Send Mail</a>
                                                    </td>
                                                </tr>
                                                <?php $i++;  ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr><td class="text-center text-danger" colspan="7">No Borrower Yet</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\LibraryMS\resources\views/admin/late/index.blade.php ENDPATH**/ ?>