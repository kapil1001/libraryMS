<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        App\User::create([
            'name' => 'Kapil Pandey',
            'email' => 'kapil@gmail.com',
            'password' => Hash::make('kapil123'),
            'user_type' => 'admin'
        ]);

        $user = App\User::create([
            'name' => 'Kapil Dev Pandey',
            'email' => 'kapil1@gmail.com',
            'password' => Hash::make('kapil123'),
            'user_type' => 'borrower'
        ]);

        App\Profile::create([
            'phone' => '9876543210',
            'address' => 'Bhaktapur',
            'dob' => '1995-06-12',
            'id_type' => 'license',
            'id_number' => '1258/7852',
            'id_image' => '',
            'image' => '',
            'user_id' => $user->id
        ]);
    }
}
